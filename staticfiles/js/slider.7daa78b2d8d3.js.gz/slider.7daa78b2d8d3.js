function minValue(val) {
          document.getElementById('min_value').value=val; 
  
        }
function maxValue(val) {
          document.getElementById('max_value').value=val; 
  
        }



